function pozymiai = pozymiai_atpazinti(pavadinimas, eiluciu_sk)
% pozymiai = pozymiai_atpazinti(pavadinimas, eiluciu_sk)
% taikymo pavyzdys:
% pozymiai = pozymiai_atpazinti('train_data.png', 8);

% Vaizdo su pavyzdziais nuskaitymas
V = imread(pavadinimas);

% Raidziu iskirpimas ir sudeliojimas i kintamojo 'objektai' celes
V_pustonis = rgb2gray(V);
slenkstis = graythresh(V_pustonis);
V_dvejetainis = im2bw(V_pustonis, slenkstis);

% vaizde esanciu objektu konturu paieska
V_konturais = edge(uint8(V_dvejetainis));
se = strel('square', 7);
V_uzpildyti = imdilate(V_konturais, se);
V_vientisi = imfill(V_uzpildyti, 'holes');

% vientisu objektu dvejetainiame vaizde numeravimas
[O_suzymeti, Skaicius] = bwlabel(V_vientisi);

% apskaiciuojami objektu dvejetainiame vaizde pozymiai
O_pozymiai = regionprops(O_suzymeti);
O_ribos = [O_pozymiai.BoundingBox];
O_ribos = reshape(O_ribos, [4 Skaicius]);
O_centras = [O_pozymiai.Centroid];
O_centras = reshape(O_centras, [2 Skaicius]);
O_centras = O_centras';
O_centras(:,3) = 1:Skaicius;
O_centras = sortrows(O_centras, 2);

raidziu_sk = Skaicius / eiluciu_sk;
for k = 1:eiluciu_sk
    O_centras((k-1)*raidziu_sk+1:k*raidziu_sk, :) = ...
        sortrows(O_centras((k-1)*raidziu_sk+1:k*raidziu_sk, :), 3);
end

for k = 1:Skaicius
    objektai{k} = imcrop(V_dvejetainis, O_ribos(:, O_centras(k,3)));
end

% vaizdo fragmentai apkerpami, panaikinant fona is krastu
for k = 1:Skaicius
    V_fragmentas = objektai{k};
    [aukstis, plotis] = size(V_fragmentas);

    stulpeliu_sumos = sum(V_fragmentas, 1);
    V_fragmentas(:, stulpeliu_sumos == aukstis) = [];
    [aukstis, plotis] = size(V_fragmentas);

    eiluciu_sumos = sum(V_fragmentas, 2);
    V_fragmentas(eiluciu_sumos == plotis, :) = [];
    objektai{k} = V_fragmentas;
end

% Suvienodiname vaizdo fragmentu dydzius iki 70x50 ir isskiriame 35 pozymius
for k = 1:Skaicius
    V_fragmentas = objektai{k};
    V_fragmentas_7050 = imresize(V_fragmentas, [70, 50]);

    Vid_sviesumas = zeros(1, 35);
    for m = 1:7
        for n = 1:5
            Vid_sviesumas_eilutese = ...
                sum(V_fragmentas_7050((m*10-9:m*10), (n*10-9:n*10)));
            Vid_sviesumas((m-1)*5+n) = sum(Vid_sviesumas_eilutese);
        end
    end
    % 10x10 dydzio dalyje maksimali sviesumo galima reiksme - 100
    Vid_sviesumas = ((100 - Vid_sviesumas) / 100);
    Vid_sviesumas = Vid_sviesumas(:);

    pozymiai{k} = Vid_sviesumas;
end

end
