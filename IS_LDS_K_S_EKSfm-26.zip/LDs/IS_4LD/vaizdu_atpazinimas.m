%% ========================================================================
%  IS-Lab4: Raidziu atpazinimas su RBFN (pagal Navakauskas/Serackis pvz. 16.2)
%  + neuronu skaiciaus mazinimo tyrimas (Lab4 uzduotis)
% =========================================================================
clear; close all; clc;

%% 1) Raidziu pavyzdziu nuskaitymas ir pozymiu skaiciavimas (mokymui)
pavadinimas = 'train_data.png';
eiluciu_sk_mokymui = 8;     % train_data.png turi 8 eilutes
raidziu_sk_eiluteje = 11;   % A B C D E F G H I K J

pozymiai_tinklo_mokymui = pozymiai_atpazinti(pavadinimas, eiluciu_sk_mokymui);

% pozymiai is celiu masyvo perkeliami i matrica
P = cell2mat(pozymiai_tinklo_mokymui);   % 35 x 88

% pageidaujamu atsakymu matrica: 11 raidziu, 8 eilutes mokymui
T = repmat(eye(raidziu_sk_eiluteje), 1, eiluciu_sk_mokymui);   % 11 x 88

%% 2) RBFN mokymas su ORIGINALIU (13) ir SUMAZINTU neuronu skaiciumi
goal = 0;
spread = 1;
MN_originalus = 13;
MN_sumazintas = 6;          % <-- cia keisk pasirinkta mazesni skaiciu

tinklas_orig   = newrb(P, T, goal, spread, MN_originalus, 1);
tinklas_mazas  = newrb(P, T, goal, spread, MN_sumazintas, 1);

%% 3) Pagalbine funkcija rezultatui i raides paversti (naudojama zemiau)
raides = {'A','B','C','D','E','F','G','H','I','K','J'};

    function atsakymas = klasifikuoti_ir_paversti_i_raides(tinklas, P_test, raides)
        Y = sim(tinklas, P_test);
        [~, b] = max(Y);
        atsakymas = '';
        for k = 1:length(b)
            atsakymas = [atsakymas, raides{b(k)}]; %#ok<AGROW>
        end
    end

%% 4) Tinklo patikra su mokymo metu naudotomis raidemis (2-a eilute, pvz.)
P2 = P(:, raidziu_sk_eiluteje+1 : 2*raidziu_sk_eiluteje);
atsakymas_orig_mok  = klasifikuoti_ir_paversti_i_raides(tinklas_orig,  P2, raides);
atsakymas_mazas_mok = klasifikuoti_ir_paversti_i_raides(tinklas_mazas, P2, raides);

fprintf('Mokymo pavyzdziu (2-a eilute) atpazinimas:\n');
fprintf('  RBFN %d neuronu:  %s\n', MN_originalus,  atsakymas_orig_mok);
fprintf('  RBFN %d neuronu:  %s\n', MN_sumazintas,  atsakymas_mazas_mok);

%% 5) Zodzio "KADA" pozymiu isskyrimas ir atpazinimas
pavadinimas = 'KADA.png';
pozymiai_patikrai_kada = pozymiai_atpazinti(pavadinimas, 1);
P_kada = cell2mat(pozymiai_patikrai_kada);

atsakymas_orig_kada  = klasifikuoti_ir_paversti_i_raides(tinklas_orig,  P_kada, raides);
atsakymas_mazas_kada = klasifikuoti_ir_paversti_i_raides(tinklas_mazas, P_kada, raides);

fprintf('\nZodzio "KADA" atpazinimas:\n');
fprintf('  RBFN %d neuronu:  %s\n', MN_originalus,  atsakymas_orig_kada);
fprintf('  RBFN %d neuronu:  %s\n', MN_sumazintas,  atsakymas_mazas_kada);

%% 6) Zodzio "FIKCIJA" pozymiu isskyrimas ir atpazinimas
pavadinimas = 'FIKCIJA.png';
pozymiai_patikrai_fikcija = pozymiai_atpazinti(pavadinimas, 1);
P_fikcija = cell2mat(pozymiai_patikrai_fikcija);

atsakymas_orig_fikcija  = klasifikuoti_ir_paversti_i_raides(tinklas_orig,  P_fikcija, raides);
atsakymas_mazas_fikcija = klasifikuoti_ir_paversti_i_raides(tinklas_mazas, P_fikcija, raides);

fprintf('\nZodzio "FIKCIJA" atpazinimas:\n');
fprintf('  RBFN %d neuronu:  %s\n', MN_originalus,  atsakymas_orig_fikcija);
fprintf('  RBFN %d neuronu:  %s\n', MN_sumazintas,  atsakymas_mazas_fikcija);

%% 7) Rezultatu atvaizdavimas (kaip knygoje, E51)
figure(7);
subplot(2,1,1);
text(0.1, 0.7, ['KADA (', num2str(MN_originalus), ' n.): ', atsakymas_orig_kada], 'FontSize', 20);
text(0.1, 0.3, ['KADA (', num2str(MN_sumazintas), ' n.): ', atsakymas_mazas_kada], 'FontSize', 20);
axis off;
subplot(2,1,2);
text(0.1, 0.7, ['FIKCIJA (', num2str(MN_originalus), ' n.): ', atsakymas_orig_fikcija], 'FontSize', 20);
text(0.1, 0.3, ['FIKCIJA (', num2str(MN_sumazintas), ' n.): ', atsakymas_mazas_fikcija], 'FontSize', 20);
axis off;
