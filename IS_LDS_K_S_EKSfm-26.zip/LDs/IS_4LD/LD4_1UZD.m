%% ========================================================================
%  IS-Lab4: Ranka rašytų skaičių atpažinimas su RBFN (ir papildomai MLP)
%  Kintamieji ir svoriai NEsujungti į bendrus masyvus/struktūras - kiekvienas
%  žingsnis laikomas savo pavadinimu turinčiuose kintamuosiuose.
% =========================================================================
clear; close all; clc;

%% 0) NUSTATYMAI (tavo vaizdų failai + eilučių skaičius kiekviename vaizde)
mokymo_vaizdo_failas   = 'train_data.png';   % pats nusifotografuoji/nuskanuoji
testavimo_vaizdo_failas= 'KADA.png';
eiluciu_sk_mokymui      = 3;   % kiek eilučių su 0..9 yra mokymo vaizde
eiluciu_sk_testavimui   = 1;   % kiek eilučių su 0..9 yra testavimo vaizde
langelio_H = 70;   % simbolio langelio aukštis (taškais)
langelio_W = 50;   % simbolio langelio plotis (taškais)
blokai_eilutese  = 7;   % 7 blokai vertikaliai
blokai_stulpeliuose = 5; % 5 blokai horizontaliai  -> 5*7 = 35 pozymiai

%% 1) POŽYMIŲ IŠSKYRIMO FUNKCIJA (atitikmuo "pozymiai_raidems_atpazinti.m")
% [P, T] = mano_pozymiai_raidems_atpazinti(failas, eiluciu_sk, H, W, bE, bS)
% P - 35 x N pozymiu matrica (N = eiluciu_sk*10 simboliu)
% T - 10 x N tiksliniu (one-hot) vektoriu, T(k,n)=1 jei n-tas simbolis yra "k-1"

%% 2) SUFORMUOJAME MOKYMO IR TESTAVIMO POŽYMIUS
[P_mok,  T_mok]  = mano_pozymiai_raidems_atpazinti(mokymo_vaizdo_failas, ...
                        eiluciu_sk_mokymui, langelio_H, langelio_W, ...
                        blokai_eilutese, blokai_stulpeliuose);

[P_test, T_test] = mano_pozymiai_raidems_atpazinti(testavimo_vaizdo_failas, ...
                        eiluciu_sk_testavimui, langelio_H, langelio_W, ...
                        blokai_eilutese, blokai_stulpeliuose);

%% 3) RBFN TINKLO MOKYMAS SU SKIRTINGU NEURONU SKAICIUMI (13 -> mazesnis)
goal   = 0.0;      % vidutinės kvadratinės klaidos tikslas
spread = 100;      % RBF plotis (Gauso funkcijos "spread"), parenkamas empiriskai
MN_originalus = 13;               % originalus max neuronu skaicius uzduotyje
MN_sumazintas = 6;                % TAVO pasirinktas mazesnis skaicius (pakeisk pagal reikia)

net_originalus  = newrb(P_mok, T_mok, goal, spread, MN_originalus, 1);
net_sumazintas  = newrb(P_mok, T_mok, goal, spread, MN_sumazintas, 1);

%% 4) TESTAVIMAS SU MOKYMO IR TESTAVIMO DUOMENIMIS ABIEM TINKLAMS
Y_mok_orig   = sim(net_originalus, P_mok);
Y_test_orig  = sim(net_originalus, P_test);
Y_mok_mazas  = sim(net_sumazintas, P_mok);
Y_test_mazas = sim(net_sumazintas, P_test);

[~, atspeti_mok_orig]   = max(Y_mok_orig,  [], 1);
[~, atspeti_test_orig]  = max(Y_test_orig, [], 1);
[~, atspeti_mok_mazas]  = max(Y_mok_mazas, [], 1);
[~, atspeti_test_mazas] = max(Y_test_mazas,[], 1);

[~, tikri_mok]  = max(T_mok,  [], 1);
[~, tikri_test] = max(T_test, [], 1);

tikslumas_mok_orig   = 100 * sum(atspeti_mok_orig   == tikri_mok)  / length(tikri_mok);
tikslumas_test_orig  = 100 * sum(atspeti_test_orig  == tikri_test)/ length(tikri_test);
tikslumas_mok_mazas  = 100 * sum(atspeti_mok_mazas  == tikri_mok)  / length(tikri_mok);
tikslumas_test_mazas = 100 * sum(atspeti_test_mazas == tikri_test)/ length(tikri_test);

fprintf('RBFN su %d neuronu:\n', MN_originalus);
fprintf('  Mokymo tikslumas:    %.1f %%\n', tikslumas_mok_orig);
fprintf('  Testavimo tikslumas: %.1f %%\n', tikslumas_test_orig);
fprintf('RBFN su %d neuronu (sumazintas):\n', MN_sumazintas);
fprintf('  Mokymo tikslumas:    %.1f %%\n', tikslumas_mok_mazas);
fprintf('  Testavimo tikslumas: %.1f %%\n', tikslumas_test_mazas);

%% 5) (PAPILDOMA UZDUOTIS, +2 balai) MLP PALYGINIMUI SU "feedforwardnet"
paslepto_sluoksnio_neuronai = 20;
mlp_tinklas = feedforwardnet(paslepto_sluoksnio_neuronai);
mlp_tinklas.trainParam.showWindow = false;
mlp_tinklas = train(mlp_tinklas, P_mok, T_mok);

Y_test_mlp = sim(mlp_tinklas, P_test);
[~, atspeti_test_mlp] = max(Y_test_mlp, [], 1);
tikslumas_test_mlp = 100 * sum(atspeti_test_mlp == tikri_test) / length(tikri_test);

fprintf('MLP (feedforwardnet, %d paslepti neuronai):\n', paslepto_sluoksnio_neuronai);
fprintf('  Testavimo tikslumas: %.1f %%\n', tikslumas_test_mlp);

%% ========================================================================
function [P, T] = mano_pozymiai_raidems_atpazinti(failo_vardas, eiluciu_sk, H, W, bE, bS)
% Nuskaito vaizda su ranka rasytais skaiciais 0..9, suskaido i langelius,
% binarizuoja, ismato 50x70 (H x W) ir isskiria bE*bS (pvz. 7*5=35) pozymius
% kaip vidutini pikseliu intensyvuma kiekviename bloke.
%
% Vaizde tikimasi eiluciu_sk eiluciu, kiekvienoje eiluteje 10 simboliu (0..9),
% simboliai isdesyti tolygiais tarpais per visa vaizdo plotĺ ir aukstĺ.

    img = imread(failo_vardas);
    if size(img,3) == 3
        img = rgb2gray(img);
    end
    bw = imbinarize(img);           % 1 = fonas (balta), 0 = raide (juoda) - patikrink poliskuma
    if mean(bw(:)) < 0.5
        bw = ~bw;                   % jei fonas tamsus, invertuojame
    end

    [aukstis, plotis] = size(bw);
    simboliu_stulpeliai = 10;                          % skaitmenys 0..9
    langelio_aukstis_vaizde = aukstis / eiluciu_sk;
    langelio_plotis_vaizde  = plotis  / simboliu_stulpeliai;

    N = eiluciu_sk * simboliu_stulpeliai;
    P = zeros(bE*bS, N);
    T = zeros(10, N);

    n = 0;
    for e = 1:eiluciu_sk
        for s = 1:simboliu_stulpeliai
            n = n + 1;

            r1 = round((e-1)*langelio_aukstis_vaizde) + 1;
            r2 = round(e*langelio_aukstis_vaizde);
            c1 = round((s-1)*langelio_plotis_vaizde) + 1;
            c2 = round(s*langelio_plotis_vaizde);

            langelis = bw(r1:r2, c1:c2);
            langelis = imresize(langelis, [H, W]);   % standartinis 50x70 dydis
            langelis = double(~langelis);             % 1 = simbolio pikselis

            blokoH = H / bE;
            blokoW = W / bS;
            pozymiai = zeros(bE, bS);
            for i = 1:bE
                for j = 1:bS
                    ri1 = round((i-1)*blokoH) + 1; ri2 = round(i*blokoH);
                    rj1 = round((j-1)*blokoW) + 1; rj2 = round(j*blokoW);
                    blokas = langelis(ri1:ri2, rj1:rj2);
                    pozymiai(i,j) = mean(blokas(:));
                end
            end

            P(:,n) = reshape(pozymiai, [], 1);

            klase = mod(s, 10);      % s=1..10 -> skaitmuo 1..9,0
            T(klase+1, n) = 1;
        end
    end
end
